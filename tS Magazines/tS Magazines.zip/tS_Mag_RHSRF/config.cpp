
#define _ARMA_

//Class rhs_sounds : config.bin{
class CfgPatches
{
	class tS_Mag_RHSRF
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] = {"rhs_c_weapons"};
		magazines[] = {};
		ammo[] = {};
		
		version = "v0.1";
		author = "10Dozen";
	};
};

class cfgMagazines
{
	class CA_Magazine;
	// Type:	5.45x39mm
	#define		SET_CLASS_545x39mm	{ magazineGroup[] = {"tS_Mag_545x39mm"}; }
	
	class rhs_30Rnd_545x39_AK : CA_Magazine SET_CLASS_545x39mm
	class rhs_30Rnd_545x39_AK_no_tracers : rhs_30Rnd_545x39_AK SET_CLASS_545x39mm
	class rhs_30Rnd_545x39_AK_green : rhs_30Rnd_545x39_AK SET_CLASS_545x39mm
	class rhs_30Rnd_545x39_7N10_AK : rhs_30Rnd_545x39_AK SET_CLASS_545x39mm
	class rhs_30Rnd_545x39_7N22_AK : rhs_30Rnd_545x39_7N10_AK SET_CLASS_545x39mm
	class rhs_30Rnd_545x39_7U1_AK : rhs_30Rnd_545x39_7N10_AK SET_CLASS_545x39mm
	class rhs_45Rnd_545X39_7N22_AK : rhs_30Rnd_545x39_7N22_AK SET_CLASS_545x39mm
	class rhs_45Rnd_545X39_7N10_AK : rhs_30Rnd_545x39_7N10_AK SET_CLASS_545x39mm
	class rhs_45Rnd_545X39_AK_Green : rhs_30Rnd_545x39_AK_green SET_CLASS_545x39mm
	class rhs_45Rnd_545X39_AK : rhs_30Rnd_545x39_AK SET_CLASS_545x39mm
	class rhs_45Rnd_545X39_7U1_AK : rhs_30Rnd_545x39_7U1_AK SET_CLASS_545x39mm

	// Type:		7.62x39mm AK mag
	#define		SET_CLASS_762x39mm	{ magazineGroup[] = {"tS_Mag_762x39mm"}; }
	class rhs_30Rnd_762x39mm : rhs_30Rnd_545x39_AK SET_CLASS_762x39mm
	class rhs_30Rnd_762x39mm_tracer : rhs_30Rnd_762x39mm SET_CLASS_762x39mm
	class rhs_30Rnd_762x39mm_89 : rhs_30Rnd_762x39mm SET_CLASS_762x39mm
	class rhs_30Rnd_762x39mm_U : rhs_30Rnd_762x39mm SET_CLASS_762x39mm
	
	// Type:		762x54mmR SVD mag
	#define		SET_CLASS_762x54mmR_SVD	{ magazineGroup[] = {"tS_Mag_762x54mmR_SVD"}; }
	class rhs_10Rnd_762x54mmR_7N1 : rhs_30Rnd_545x39_AK SET_CLASS_762x54mmR_SVD
	
	// Type:		762x54mmR MG box
	#define		SET_CLASS_762x54mmR_Box	{ magazineGroup[] = {"tS_Mag_762x54mmR_Box"}; }
	class rhs_100Rnd_762x54mmR : rhs_30Rnd_545x39_AK SET_CLASS_762x54mmR_Box
	class rhs_100Rnd_762x54mmR_green : rhs_100Rnd_762x54mmR SET_CLASS_762x54mmR_Box
	
	// Type:		VOG UGL round
	#define		SET_CLASS_VOG	{ magazineGroup[] = {"tS_Mag_VOG"}; }
	
	class 1Rnd_HE_Grenade_shell;
	class rhs_VOG25 : 1Rnd_HE_Grenade_shell SET_CLASS_VOG
	class rhs_VOG25P : rhs_VOG25 SET_CLASS_VOG
	class rhs_VG40TB : rhs_VOG25 SET_CLASS_VOG
	class rhs_VG40SZ : rhs_VOG25 SET_CLASS_VOG
	class rhs_VG40OP_white : rhs_VOG25 SET_CLASS_VOG
	class rhs_VG40OP_green : rhs_VG40OP_white SET_CLASS_VOG
	class rhs_VG40OP_red : rhs_VG40OP_white SET_CLASS_VOG	
	class rhs_GRD40_White : rhs_VOG25 SET_CLASS_VOG
	class rhs_GRD40_Green : rhs_GRD40_White SET_CLASS_VOG
	class rhs_GRD40_Red : rhs_GRD40_White SET_CLASS_VOG
	class rhs_VG40MD_White : rhs_GRD40_White SET_CLASS_VOG
	class rhs_VG40MD_Green : rhs_GRD40_Green SET_CLASS_VOG
	class rhs_VG40MD_Red : rhs_GRD40_Red SET_CLASS_VOG
	class rhs_GDM40 : rhs_GRD40_White SET_CLASS_VOG
	
};

class cfgWeapons
{
	
	#define	ADD_MAG_545x39mm	{ magazines[] = {"tS_Mag_545x39mm"}; };
	#define	ADD_MAG_762x39mm	{ magazines[] = {"tS_Mag_762x39mm"}; };
	#define	ADD_MAG_762x54R_Box	{ magazines[] = {"tS_Mag_762x54mmR_Box"}; };
	#define	ADD_MAG_762x54R_SVD	{ magazines[] = {"tS_Mag_762x54mmR_SVD"}; };
	#define	ADD_MAG_VOG		{ magazines[] = {"tS_Mag_VOG"}; };
	
	class Rifle_Base_F;
	class rhs_weap_ak74m_Base_F : Rifle_Base_F ADD_MAG_545x39mm
	class rhs_weap_ak74m : rhs_weap_ak74m_Base_F ADD_MAG_545x39mm
	class rhs_weap_ak74m_camo : rhs_weap_ak74m ADD_MAG_545x39mm
	class rhs_weap_ak74m_npz : rhs_weap_ak74m ADD_MAG_545x39mm
	class rhs_weap_ak74m_desert_npz : rhs_weap_ak74m_npz ADD_MAG_545x39mm
	class rhs_weap_ak74m_camo_npz : rhs_weap_ak74m_npz ADD_MAG_545x39mm
	class rhs_weap_ak74m_folded : rhs_weap_ak74m ADD_MAG_545x39mm
	class rhs_weap_ak74m_camo_folded : rhs_weap_ak74m_folded ADD_MAG_545x39mm
	class rhs_weap_ak74m_desert_folded : rhs_weap_ak74m_folded ADD_MAG_545x39mm
	class rhs_weap_ak74m_plummag_folded : rhs_weap_ak74m_folded ADD_MAG_545x39mm
	class rhs_weap_ak74m_gp25_folded : rhs_weap_ak74m_folded ADD_MAG_545x39mm
	class rhs_weap_ak74m_2mag : rhs_weap_ak74m ADD_MAG_545x39mm
	class rhs_weap_ak74m_2mag_npz : rhs_weap_ak74m_2mag ADD_MAG_545x39mm
	class rhs_weap_ak74m_2mag_camo_npz : rhs_weap_ak74m_2mag_npz ADD_MAG_545x39mm
	class rhs_weap_ak74m_2mag_camo : rhs_weap_ak74m_2mag ADD_MAG_545x39mm
	class rhs_weap_ak74m_desert : rhs_weap_ak74m ADD_MAG_545x39mm
	class rhs_weap_ak74m_plummag : rhs_weap_ak74m ADD_MAG_545x39mm
	class rhs_weap_ak74m_plummag_npz : rhs_weap_ak74m_npz ADD_MAG_545x39mm
	class rhs_weap_ak74m_gp25 : rhs_weap_ak74m ADD_MAG_545x39mm
	class rhs_weap_ak74m_gp25_npz : rhs_weap_ak74m_gp25 ADD_MAG_545x39mm
	class rhs_weap_ak74 : rhs_weap_ak74m ADD_MAG_545x39mm
	class rhs_weap_ak74_gp25 : rhs_weap_ak74m_gp25 ADD_MAG_545x39mm
	class rhs_weap_aks74 : rhs_weap_ak74 ADD_MAG_545x39mm
	class rhs_weap_aks74u : rhs_weap_aks74 ADD_MAG_545x39mm
	
	class rhs_weap_ak105 : rhs_weap_ak74m ADD_MAG_545x39mm
	class rhs_weap_ak105_npz : rhs_weap_ak105 ADD_MAG_545x39mm
	
	class rhs_weap_akm : rhs_weap_ak74m ADD_MAG_762x39mm
	class rhs_weap_akm_gp25 : rhs_weap_akm ADD_MAG_762x39mm
	class rhs_weap_akms : rhs_weap_akm ADD_MAG_762x39mm
	class rhs_weap_akms_gp25 : rhs_weap_akm ADD_MAG_762x39mm
	
	class rhs_weap_ak103_base : rhs_weap_akm ADD_MAG_762x39mm
	class rhs_weap_ak103 : rhs_weap_ak103_base ADD_MAG_762x39mm
	class rhs_weap_ak104 : rhs_weap_ak103_base ADD_MAG_762x39mm
	class rhs_weap_ak104_npz : rhs_weap_ak104 ADD_MAG_762x39mm
	class rhs_weap_ak103_npz : rhs_weap_ak103 ADD_MAG_762x39mm
	class rhs_weap_ak103_1 : rhs_weap_ak103_base ADD_MAG_762x39mm
	class rhs_weap_ak103_2 : rhs_weap_ak103_base ADD_MAG_762x39mm
	class rhs_weap_ak103_gp25 : rhs_weap_ak103_base ADD_MAG_762x39mm
	class rhs_weap_ak103_gp25_npz : rhs_weap_ak103_base ADD_MAG_762x39mm
	
	



	class UGL_F;
	class  GP25_Base : UGL_F ADD_MAG_VOG
};